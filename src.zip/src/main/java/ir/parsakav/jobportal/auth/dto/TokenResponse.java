package ir.parsakav.jobportal.auth.dto;

// com/example/sjp/auth/dto/TokenResponse.java

import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class TokenResponse {
    private String token;
}
