package ir.parsakav.jobportal.accounts.domain;

public enum Role { SEEKER, EMPLOYER, ADMIN }
